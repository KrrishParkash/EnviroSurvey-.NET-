﻿using EcommerceDb.Models;
using Microsoft.EntityFrameworkCore;

namespace EcommerceDb.SqlDbContext
{
    public class SqlContext :DbContext
    {
        public SqlContext(DbContextOptions<SqlContext> options) : base(options)
        {
        
        
        }
        public DbSet<Category>tblcategory { get; set; }
        public DbSet<Product> tblproduct { get; set; }
        public DbSet<Customer> tblcustomer { get; set; }
    }
}
