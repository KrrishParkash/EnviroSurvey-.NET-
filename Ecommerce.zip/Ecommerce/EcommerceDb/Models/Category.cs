﻿using System.ComponentModel.DataAnnotations;

namespace EcommerceDb.Models
{
    public class Category
    { 
        public int CategoryId { get; set; }

        [Required(ErrorMessage ="name is required")]
        public string CategoryName { get; set; }
    }
}
