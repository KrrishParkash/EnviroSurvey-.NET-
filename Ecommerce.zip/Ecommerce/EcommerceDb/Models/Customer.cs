﻿using System.ComponentModel.DataAnnotations;

namespace EcommerceDb.Models
{
    public class Customer
    {
        [Key]
        public int CustomerId { get; set; }

        [Required(ErrorMessage = "name is required")]
        public string CustomerName { get; set; }

        [DataType(DataType.EmailAddress)]
        public string CustomerEmail { get; set; }

        public int CustomerPhone { get; set; }

        public string CustomerAddress { get; set; }
    }
}
