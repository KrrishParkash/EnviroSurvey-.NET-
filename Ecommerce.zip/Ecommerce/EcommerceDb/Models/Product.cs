﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EcommerceDb.Models
{
    public class Product
    {
        [Key]
        public int  ProductId { get; set; }

        [Required(ErrorMessage = "name is required")]
        public string ProductName { get; set; }

        public string ProductDescription { get; set; }

        public int ProductPrice { get; set; }

        public int ProductStock { get; set; }

        public int ProductCategory { get; set; }
        [ForeignKey("ProductCategory")]
        public virtual Category category { get; set; }
    }
}
