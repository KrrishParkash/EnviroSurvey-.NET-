﻿using EcommerceDb.Models;
using EcommerceDb.SqlDbContext;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EcommerceDb.Controllers
{
    public class AdminController : Controller
    {
        SqlContext sc;
        public AdminController(SqlContext sc)
        {
            this.sc = sc;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult category()
        {
            return View(sc.tblcategory.ToList());
        }

        public IActionResult Createcategory()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Createcategory(Category cat)
        {  
            sc.tblcategory.Add(cat);
            sc.SaveChanges();
            return RedirectToAction("category");
        }


        public IActionResult deletecategory(int id)
        {
            var ca = sc.tblcategory.ToList();
            ViewBag.Category = ca;
            var cat = sc.tblcategory.Find(id);
            return View(cat);
        }

        [HttpPost]
        public IActionResult deletecategory(Category cat)
        {
            sc.tblcategory.Remove(cat);
            sc.SaveChanges();
            return RedirectToAction("category");

        }

        public IActionResult product()
        {
            return View(sc.tblproduct.Include(x=>x.category).ToList());
        }

        public IActionResult Createproduct()
        {
            var cat = sc.tblcategory.ToList();
            ViewBag.Category = cat;
            return View();
        }

        [HttpPost]
        public IActionResult Createproduct(Product prod)
        {
            if (prod.ProductPrice>0)
            {
                sc.tblproduct.Add(prod);
                sc.SaveChanges();
                return RedirectToAction("product");
            }
            else
            {
                TempData["danger"] = "not inserted";
                return RedirectToAction("product");
            }
        }

        public IActionResult deleteproduct(int id)
        {
            var cat = sc.tblcategory.ToList();
            ViewBag.Category = cat;
            var prod=  sc.tblproduct.Find(id);
            return View(prod);
        }

        [HttpPost]
        public IActionResult deleteproduct(Product prod)
        {
            sc.tblproduct.Remove(prod);
            sc.SaveChanges();
            return RedirectToAction("product");

        }

        public IActionResult customer()
        {
            return View(sc.tblcustomer.ToList());
        }

        public IActionResult Createcustomer()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Createcustomer(Customer cs)
        {
            sc.tblcustomer.Add(cs);
            sc.SaveChanges();
            return RedirectToAction("customer");
        }


        public IActionResult deletecustomer(int id)
        {
            
            var cat = sc.tblcustomer.Find(id);
            return View(cat);
        }

        [HttpPost]
        public IActionResult deletecustomer(Customer cs)
        {
            sc.tblcustomer.Remove(cs);
            sc.SaveChanges();
            return RedirectToAction("customer");

        }
    }
}
